package com.example.musclepluscompose.data

enum class SortType {
    NAME
}